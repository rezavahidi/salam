package Model;

public class Spell extends Card{

    public Spell(String name,String description,String type,int price,String category){
        super(name,description,type,price,category);
    }

}
